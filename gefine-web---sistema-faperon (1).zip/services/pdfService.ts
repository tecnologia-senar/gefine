
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';
import { mockAssociados, mockSindicato, mockColaboradores, mockEventos } from '../mockData';

// Helper to initialize PDF with header
const initPDF = (title: string) => {
  const doc = new jsPDF();
  
  // Header Green Bar
  doc.setFillColor(22, 163, 74); // green-600
  doc.rect(0, 0, 210, 20, 'F');
  
  // Title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text("GEFINE - SISTEMA FAPERON", 14, 13);
  
  // Report Title
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(16);
  doc.text(title, 14, 35);
  
  // Date
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`Gerado em: ${new Date().toLocaleDateString()} às ${new Date().toLocaleTimeString()}`, 14, 42);
  
  return doc;
};

export const generateSindicatoReport = () => {
  const doc = initPDF("Informações do Sindicato");
  const s = mockSindicato;

  doc.setFontSize(12);
  doc.setTextColor(0);

  let y = 60;
  const lineHeight = 10;

  const addField = (label: string, value: string) => {
    doc.setFont('helvetica', 'bold');
    doc.text(`${label}:`, 14, y);
    doc.setFont('helvetica', 'normal');
    doc.text(value || '-', 70, y);
    y += lineHeight;
  };

  addField("Nome", s.Nome);
  addField("Presidente", s.Presidente);
  addField("Gerente", s.Gerente);
  addField("CNPJ", s.CNPJ);
  addField("Telefone", s.Telefone);
  addField("Email", s.Email);
  addField("Endereço", `${s.Endereco}, ${s.Numero}`);
  addField("Bairro", s.Bairro);
  addField("Cidade", `${s.Cidade} - ${s.Estado}`);
  addField("CEP", s.CEP);

  doc.save("Ficha_Sindicato.pdf");
};

export const generateAssociadosReport = (filter: 'TODOS' | 'ATIVOS' | 'INATIVOS' | 'APTOS', sort: 'ALFA' | 'MATRICULA') => {
  const doc = initPDF(`Relatório de Associados - ${filter}`);
  
  let data = [...mockAssociados];

  // Filter
  if (filter === 'ATIVOS') {
    data = data.filter(a => a.Status.includes('ATIVO'));
  } else if (filter === 'INATIVOS') {
    data = data.filter(a => !a.Status.includes('ATIVO'));
  }
  // 'APTOS' logic would go here (mock same as ATIVOS for now)
  if (filter === 'APTOS') {
    data = data.filter(a => a.Status.includes('ATIVO')); 
  }

  // Sort
  if (sort === 'ALFA') {
    data.sort((a, b) => a.Nome_Produtor.localeCompare(b.Nome_Produtor));
  } else {
    data.sort((a, b) => a.Matricula.localeCompare(b.Matricula));
  }

  const tableData = data.map(a => [
    a.Matricula,
    a.Nome_Produtor,
    a.CPF,
    a.Municipio,
    a.Status
  ]);

  autoTable(doc, {
    startY: 50,
    head: [['Matrícula', 'Nome', 'CPF', 'Município', 'Status']],
    body: tableData,
    headStyles: { fillColor: [22, 163, 74] },
    styles: { fontSize: 10 },
  });

  doc.save(`Associados_${filter}_${sort}.pdf`);
};

export const generateColaboradoresReport = () => {
  const doc = initPDF("Relação de Colaboradores");

  const tableData = mockColaboradores.map(c => [
    c.Nome,
    c.Funcao,
    c.CPF,
    new Date(c.Data_Admissao).toLocaleDateString()
  ]);

  autoTable(doc, {
    startY: 50,
    head: [['Nome', 'Função', 'CPF', 'Admissão']],
    body: tableData,
    headStyles: { fillColor: [22, 163, 74] },
  });

  doc.save("Colaboradores.pdf");
};

export const generateChapasReport = () => {
  const doc = initPDF("Histórico de Chapas Eleitas");
  
  // Mock data for report as we don't have specific mockChapas in main file
  const data = [
    ["2020-2024", "União e Força", "Hélio Dias", "2020-01-01", "2024-12-31"],
    ["2016-2020", "Progresso Rural", "João Silva", "2016-01-01", "2020-12-31"]
  ];

  autoTable(doc, {
    startY: 50,
    head: [['Gestão', 'Chapa', 'Presidente', 'Início', 'Fim']],
    body: data,
    headStyles: { fillColor: [30, 58, 138] }, // Blue header for Diretorias
  });

  doc.save("Historico_Chapas.pdf");
};

export const generateEventosReport = () => {
  const doc = initPDF("Relatório de Eventos");

  const tableData = mockEventos.map(e => [
    e.Nome,
    e.Tipo,
    `${new Date(e.Data_Inicio).toLocaleDateString()} a ${new Date(e.Data_Fim).toLocaleDateString()}`,
    e.Local_Realizacao,
    e.Responsavel
  ]);

  autoTable(doc, {
    startY: 50,
    head: [['Nome do Evento', 'Tipo', 'Período', 'Local', 'Responsável']],
    body: tableData,
    headStyles: { fillColor: [107, 33, 168] }, // Purple for Events
  });

  doc.save("Relatorio_Eventos.pdf");
};

export const generateGenericReport = (title: string) => {
   const doc = initPDF(title);
   doc.text("Relatório gerado pelo sistema.", 14, 60);
   doc.text("Dados demonstrativos.", 14, 70);
   doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
}
