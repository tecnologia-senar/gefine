
import { GoogleGenAI } from "@google/genai";

// Initialize the client
// The API key must be obtained exclusively from the environment variable process.env.API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeFinancialData = async (data: string, query: string): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    const prompt = `
      Você é um assistente financeiro especializado no sistema GEFINE (Gestão Financeira e de Eventos).
      
      Aqui estão os dados financeiros recentes (JSON):
      ${data}

      Pergunta do usuário: ${query}

      Por favor, forneça uma resposta concisa e analítica. Se houver números, formate-os como moeda (R$).
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Não foi possível gerar uma análise no momento.";
  } catch (error) {
    console.error("Erro ao chamar Gemini API:", error);
    return "Erro ao processar sua solicitação. Verifique a chave de API.";
  }
};